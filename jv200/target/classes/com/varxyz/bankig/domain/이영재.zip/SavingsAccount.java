package com.varxyz.bankig.domain;

public class SavingsAccount extends Account {
	private double interestRate; //이자율
	
	public void withdraw(double amount) {
		if (balance - amount < 0) { //예외발생
			throw new Accountbalanceinsufficient("잔고부족");
		}
		super.balance -= amount;
	}
	
}

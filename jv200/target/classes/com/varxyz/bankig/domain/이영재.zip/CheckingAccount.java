package com.varxyz.bankig.domain;

public class CheckingAccount extends Account {
	private double overdraftAmount = 10.0; // 대출
	
	public void withdraw(double amount) {
		if (balance < amount) {
			//잔고부족시 overdraftAmount 금액 한도 내에서 추가 출금을 승인
			double number = amount -= balance;
			overdraftAmount -= number; //부족한 만큼 대출한다
			System.out.println("잔액이 부족하여" +number+"만큼 대출하였습니다");
		}else {
			balance -= amount;
		}
	}
}

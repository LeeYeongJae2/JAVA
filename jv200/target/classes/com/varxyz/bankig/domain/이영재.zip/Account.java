package com.varxyz.bankig.domain;

public class Account { // 80점이라면 정말 감사하겠습니다 ㅜㅜ
	protected double balance;
	protected String accoutNum;
	
	public void deposite(double amount, String num) { // 돈을 통장에저장 계좌번호를 설정한다
		this.balance += amount;
		this.accoutNum = num;
	}
	
	
	public void checkthebalance(String num) { //현재 계좌에 얼마가 들어있는지 반환해준다
		if (accoutNum == num) { //계좌번호가 틀리면 확인하지 못한다
			System.out.println("계좌잔액: " + balance);
		}
		else {
			System.out.println("계좌번호가 틀렸습니다");
		}
	}
	
	public double withdrawal(double number) { //계좌에서 출금한다
		if (balance < number) { // 잔액보다 많으면 출금하지 못한다
			System.out.println("출금 금액이 잔액보다 많습니다 남은금액:");
			return balance;
		}
		System.out.println("출금되었습니다");
		balance -= number; //츨금 금액만큼 통장에서 뺀다
		return number;
		
	}
	
	
	public static void main(String[] args) {
		
		Account a = new Account();
		a.deposite(10,"12345"); //계좌에 돈을 넣고 계좌번호를 설정한다
		a.checkthebalance("12345"); //계좌번호를 입력후 잔액을 확인할수 있다
		System.out.println(a.withdrawal(10));
		
		CheckingAccount b = new CheckingAccount();
		b.withdraw(20); // 대출받을 금액
		
		
		
		
		
	}
}
